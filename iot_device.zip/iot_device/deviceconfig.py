import paho.mqtt.client as mqtt
import time
import random
import json

# MQTT Configuration
BROKER = "localhost"
PORT = 1883
TOPIC_SENSOR = "iot/sensor"
TOPIC_CONFIG = "iot/config"
CLIENT_ID = "PythonClient"

# Default Device Config
config = {
    "interval": 5  # Default interval (seconds) for sending sensor data
}

# Callback when a config update is received
def on_message(client, userdata, msg):
    global config
    try:
        new_config = json.loads(msg.payload.decode())
        config.update(new_config)
        print(f"Received Config Update: {config}")
    except Exception as e:
        print(f"Error processing config update: {e}")

# Initialize MQTT Client
client = mqtt.Client(client_id=CLIENT_ID, protocol=mqtt.MQTTv311)
client.on_message = on_message  # Attach callback

# Connect and Subscribe to Config Topic
client.connect(BROKER, PORT, 60)
client.subscribe(TOPIC_CONFIG)

# Start MQTT loop in a separate thread
client.loop_start()

try:
    while True:
        # Generate Fake Sensor Data
        temperature = random.uniform(20.0, 30.0)
        message = json.dumps({"temperature": round(temperature, 2)})

        # Publish Sensor Data
        client.publish(TOPIC_SENSOR, message)
        print(f"Sent: {message}")

        time.sleep(config["interval"])  # Use dynamic interval from config

except KeyboardInterrupt:
    print("\nStopping MQTT Client...")
    client.loop_stop()
    client.disconnect()
