import paho.mqtt.client as mqtt
import random
import time
import json

BROKER = "localhost"  # Public Mosquitto broker
SENSOR_TOPIC = "factory/sensor/data"
CONFIG_TOPIC = "factory/device/config"

# Default sensor settings
config = {"interval": 2, "temp_threshold": 40}

# Callback to handle config updates from backend
def on_message(client, userdata, message):
    global config
    payload = json.loads(message.payload.decode())
    print(f"Received Config Update: {payload}")
    config.update(payload)  # Update settings dynamically

# Connect to MQTT
client = mqtt.Client()
client.connect(BROKER, 1883, 60)

# Subscribe to config updates
client.subscribe(CONFIG_TOPIC)
client.on_message = on_message
client.loop_start()

# Simulate sensor readings
while True:
    sensor_data = {
        "temperature": round(random.uniform(20, 50), 2),
        "humidity": round(random.uniform(30, 80), 2),
        "vibration": round(random.uniform(0, 5), 2),
    }
    client.publish(SENSOR_TOPIC, json.dumps(sensor_data))
    print(f"Published: {sensor_data}")

    time.sleep(config["interval"])  # Use dynamic interval
